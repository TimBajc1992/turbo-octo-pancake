#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
/usr/bin/shortcuts sign --mode anyone --input "TEZISCE-Apple-Health.unsigned.shortcut" --output "TEZISCE Apple Health.shortcut"
printf '\nBliznjica je pripravljena. Poslji oznaceno datoteko na iPhone prek AirDrop in jo odpri v Bliznjicah.\n'
open -R "TEZISCE Apple Health.shortcut"
